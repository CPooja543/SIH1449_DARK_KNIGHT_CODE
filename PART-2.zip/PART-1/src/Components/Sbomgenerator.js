import React from 'react'
import { useState } from 'react'
import './Sbomgenerator.css'
export default function Sbomgenerator({submitDocumentName, submitDocumentNamespace, submitCreator, submitCreatedOn, submitCreatorComment, submitGithubUrl}) {

const [documentName, setDocumentName] = useState();
const documentNameChange = (e) =>{
    setDocumentName(e.target.value);
    console.log(e.target.value)
}
const [documentNamespace, setDocumentNamespace] = useState();
const documentNamespaceChange = (e) =>{
    setDocumentNamespace(e.target.value);
    console.log(e.target.value)
}
const [creator, setCreator] = useState();
const creatorChange = (e) =>{
    setCreator(e.target.value);
    console.log(e.target.value)
}
const [createdOn, setCreatedOn] = useState();
const createdOnChange = (e) => {
    setCreatedOn(e.target.value);
    console.log(e.target.value);
}
const [creatorComment, setCreatorComment] = useState();
const creatorCommentChange = (e) =>{
    setCreatorComment(e.target.value)
    console.log(e.target.value)
}
const [githubUrl, setGithubUrl] = useState();
const githubUrlChange = (e) =>{
    setGithubUrl(e.target.value);
    console.log(e.target.value)
}
const submitDocumentHeader = () =>{
    submitDocumentName(documentName);
    submitDocumentNamespace(documentNamespace);
    submitCreator(creator);
    submitCreatedOn(createdOn);
    submitCreatorComment(creatorComment);
    submitGithubUrl(githubUrl);
    setDocumentName();
    setDocumentNamespace();
    setCreator();
    setCreatedOn();
    setCreatorComment();
    setGithubUrl();
}
//   const [text,setText] = useState();
//   const submit = () =>{
//     console.log("submit" + text);
//     let newText = text.toUpperCase();;
//     setText(newText);
//   }
//   const handlechange = (event) =>{
//     setText(event.target.value)
//   }
//   const [mystyle, mystylef] = useState({
//     color: 'black',
//     backgroundColor: 'white'
//   })
//   const toggle = () =>{
//     if(mystyle.color=='black'){

//       mystylef({
//         color: 'white',
//         backgroundColor: 'black'
//       })
//     }
//     else{
//       mystylef({
//         color: 'black',
//         backgroundColor: 'white'
//       })
//     }
//   }
  return (
    <>
    <div className="bbody">
        <div className="bform">
            <h1 className='title'>SBOM Generator</h1>
            <input className='in' type= "text" value={documentName} onChange={documentNameChange} name='Document Name' placeholder='Document Name' />
            <input className='in' type="text" value={documentNamespace} onChange={documentNamespaceChange} name="Document Namespace" placeholder='Document Namespace'/>
            <input className='in' type="text" value={creator} onChange={creatorChange} name="Creator" placeholder='Creator'/>
            <input className='in' type="text" value={createdOn} onChange={createdOnChange} name="Created" placeholder='Created On'/>
            <input className='in' type="text" value={creatorComment} onChange={creatorCommentChange} name="Creator Comment" placeholder='Creator Comment'/>
            <input className='in' type="text" value={githubUrl} onChange={githubUrlChange} name="Github URL" placeholder='Github URL'/>
            {/* SPDV Version: SPDX-2.1
            Data License: CC0-1.0
            SPDXID: SPDXRef-DOCUMENT */}
            <button className='submit' onClick={submitDocumentHeader}>Submit</button>
            {/* <button className='submit' onClick={submit}>Submit</button> */}
            {/* <button className='submit' onClick={toggle} style={mystyle}>white</button> */}
        </div>
    </div>
    </>
  )
}
