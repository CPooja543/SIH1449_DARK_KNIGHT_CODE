import React, { useState, useEffect } from 'react';

const FetchDataComponent = () => {
  const fetchData = async () =>{
      try{
        // console.log(URL)
        const response = await fetch('https://libraries.io/api/pypi/numpy?api_key=519f64c3cb4c61b8a66640d716478d3e');
        const result = await response.json();
        // const newData = [...data, result];
        // setdata(newData)
       // setdata(result)
        console.log(result)
      }
      catch{
     //   console.error('error in fetching data');
      }
    };
  

  return (
    <div>
    </div>
  );
};

export default FetchDataComponent;
