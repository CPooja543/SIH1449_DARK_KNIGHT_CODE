import React from "react";
import "./List.css";
export default function Documentheader({outputDocumentName, outputDocumentNamespace, outputCreator, outputCreatedOn, outputCreatorComment, outputGithubUrl}) {
  return (
    <>
      <div className="body">
        <ul className="holder">
          <li>SPDXVersion: SPDX-{outputCreatedOn}-{outputCreator}</li>
          <li>DataLicense: {outputGithubUrl}</li>
          <li>SPDXID: SPDXID-{outputCreatedOn}</li>
          <li>Document Name: {outputDocumentName}</li>
          <li>Document Namespace: {outputDocumentNamespace}</li>
          <li>Creator: {outputCreator}</li>
          <li>Created On: {outputCreatedOn}</li>
          <li>Creator Comment: {outputCreatorComment}</li>
        </ul>
      </div>
    </>
  );
}
