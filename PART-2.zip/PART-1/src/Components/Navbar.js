import React from 'react'
import './Navbar.css';
export default function Navbar({searching, handleChangeSearch}) {
  return (
    <>
    <nav>
    <div className='forml'>
            <li className="home">Home</li>
            <li className="about">About </li>
            <li className="contact">Contact Us</li>
    </div>
    <div className="formr">
            <li className="search"><input className='searchin' type="text" name="name" value={searching} onChange={handleChangeSearch} placeholder='Search'/></li>
    </div>
    </nav>
    </>
  )
}
