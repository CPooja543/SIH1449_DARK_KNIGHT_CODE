import React from "react";
import "./List.css";
export default function List({ entries }) {
  const redirect_latest_download_url = () =>{
    window.location.href = entries?.latest_download_url;
  }
  const redirect_homepage = () =>{
    window.location.href = entries?.homepage;
  }
  const redirect_package_manager_url = () =>{
    window.location.href = entries?.package_manager_url;
  }
  if (!entries || !entries.versions || !Array.isArray(entries.versions) || entries.versions.length === 0) {
    return <div>Loading...</div>; // Or any loading indicator
  }
  // Accessing the published_at property of the first entry
  const firstEntry = entries.versions[0];
  const published_at = firstEntry && firstEntry.published_at;
  const original_license = firstEntry && firstEntry.original_license;
  return (
    <>
      <div className="body">
        <ul className="holder">
          <li>Package Name: {entries?.name}</li>
          <li>Package Field Name: {entries?.name}-{entries?.latest_stable_release_number}-{entries?.licenses}</li>
          <li>Package Version Field: {entries?.latest_stable_release_number}</li>
          <li>Package File Name Field: {entries?.name}-{entries?.latest_stable_release_number}.tgz</li>
          <li>Package Supplier Field: {entries?.licenses}</li>
          <li>Package Originator Field: {original_license ? entries?.versions[0]?.original_license : "N/A"}</li>
          <li onClick={redirect_latest_download_url} style={{color: 'blue'}}>Package Download Location: {entries?.latest_download_url}</li>
          <li onClick={redirect_homepage} style={{color: 'blue'}}>Package Home Page Field: {entries?.homepage}</li>
          <li onClick={redirect_package_manager_url} style={{color: 'blue'}}>Source Information Field: {entries?.package_manager_url}</li>
          <li>Package Summary Description Field: {entries?.description}</li>
          <li>Release Date: {published_at}</li>
          <li>Platform Name: {entries?.platform}</li>
          <li>Repository License: {entries?.repository_license}</li>
          <li>Repository URL: {entries?.repository_url}</li>
          {/* <li>Direct Dependencies: </li> */}
          {/* <li>Transitive Depenedencies: </li> */}
          <li>Package Latest Version Field: {entries?.latest_stable_release_number}</li>
          <li>Language: {entries?.language}</li>
        </ul>
      </div>
    </>
  );
}
