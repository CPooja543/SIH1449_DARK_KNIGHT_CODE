import React from 'react'
import { useState, useEffect } from 'react'
import './Sbomgenerator.css'
export default function Sbomgenerator({submitDocumentName, submitDocumentNamespace, submitCreator, submitCreatedOn, submitCreatorComment, submitGithubUrl}) {



    const [apiData, setApiData] = useState(null);
    const [formData, setFormData] = useState({ repo_owner: '', repo_name: '' });
  
    useEffect(() => {
      fetchData();
    }, []);
  
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:8080/depend');
        if (response.ok) {
          const data = await response.json();
          setApiData(data);
        } else {
          console.error('Failed to fetch data');
        }
      } catch (error) {
        console.error('Error:', error);
      }
    };
  
    const handleInputChange = (e) => {
      const { name, value } = e.target;
      setFormData((prevData) => ({ ...prevData, [name]: value }));
    };
  



const [documentName, setDocumentName] = useState();
const documentNameChange = (e) =>{
    setDocumentName(e.target.value);
    console.log(e.target.value)
}
const [documentNamespace, setDocumentNamespace] = useState();
const documentNamespaceChange = (e) =>{
    setDocumentNamespace(e.target.value);
    console.log(e.target.value)
}
const [creator, setCreator] = useState();
const creatorChange = (e) =>{
    setCreator(e.target.value);
    console.log(e.target.value)
}
const [createdOn, setCreatedOn] = useState();
const createdOnChange = (e) => {
    setCreatedOn(e.target.value);
    console.log(e.target.value);
}
const [creatorComment, setCreatorComment] = useState();
const creatorCommentChange = (e) =>{
    setCreatorComment(e.target.value)
    console.log(e.target.value)
}
const [githubUrl, setGithubUrl] = useState();
const githubUrlChange = (e) =>{
    setGithubUrl(e.target.value);
    console.log(e.target.value)
}
const submitDocumentHeader = async (e) =>{
    submitDocumentName(documentName);
    submitDocumentNamespace(documentNamespace);
    submitCreator(creator);
    submitCreatedOn(createdOn);
    submitCreatorComment(creatorComment);
    submitGithubUrl(githubUrl);
    setDocumentName();
    setDocumentNamespace();
    setCreator();
    setCreatedOn();
    setCreatorComment();
    setGithubUrl();

    e.preventDefault();
    try {
        const response = await fetch('http://localhost:8080/repodetails', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            repo_owner: formData.repo_owner,
            repo_name: formData.repo_name,
          }),
        });
  
        if (response.ok) {
          // Fetch data again to update the displayed data
          fetchData();
          setFormData({ repo_owner: '', repo_name: '' });
        } else {
          console.error('Failed to add data');
        }
      } catch (error) {
        console.error('Error:', error);
      }
}
//   const [text,setText] = useState();
//   const submit = () =>{
//     console.log("submit" + text);
//     let newText = text.toUpperCase();;
//     setText(newText);
//   }
//   const handlechange = (event) =>{
//     setText(event.target.value)
//   }
//   const [mystyle, mystylef] = useState({
//     color: 'black',
//     backgroundColor: 'white'
//   })
//   const toggle = () =>{
//     if(mystyle.color=='black'){

//       mystylef({
//         color: 'white',
//         backgroundColor: 'black'
//       })
//     }
//     else{
//       mystylef({
//         color: 'black',
//         backgroundColor: 'white'
//       })
//     }
//   }
  return (
    <>
    <div className="bbody">
        <div className="bform">
            <h1 className='title'>SBOM Generator</h1>
            <input className='in' type= "text" value={documentName} onChange={documentNameChange} name='Document Name' placeholder='Document Name' />
            <input className='in' type="text" value={documentNamespace} onChange={documentNamespaceChange} name="Document Namespace" placeholder='Document Namespace'/>
            <input className='in' type="text" value={creator} onChange={creatorChange} name="Creator" placeholder='Creator'/>
            <input className='in' type="text" value={createdOn} onChange={createdOnChange} name="Created" placeholder='Created On'/>
            <input className='in' type="text" value={creatorComment} onChange={creatorCommentChange} name="Creator Comment" placeholder='Creator Comment'/>
            <input className='in' type="text" value={githubUrl} onChange={githubUrlChange} name="Github URL" placeholder='Github URL'/>
            {/* SPDV Version: SPDX-2.1
            Data License: CC0-1.0
            SPDXID: SPDXRef-DOCUMENT */}
            
          <input className='in' type="text" name="repo_owner" value={formData.repo_owner} placeholder='Repository Owner' onChange={handleInputChange} />
          <input className='in' type="text" name="repo_name" value={formData.repo_name} placeholder='Repository Name' onChange={handleInputChange} />
            <button className='submit' onClick={submitDocumentHeader}>Submit</button>
            {/* <button className='submit' onClick={submit}>Submit</button> */}
            {/* <button className='submit' onClick={toggle} style={mystyle}>white</button> */}
        </div>
    </div>
    </>
  )
}
