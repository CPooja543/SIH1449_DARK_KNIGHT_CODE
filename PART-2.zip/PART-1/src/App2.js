// // import logo from './logo.svg';
// import './App.css';
// import React, {useState, useEffect} from 'react';
// import Navbar from './Components/Navbar';
// import List from './Components/List';
// import Sbomgenerator from './Components/Sbomgenerator1';
// import Documentheader from './Components/Documentheader';
// import FormComponent from './Components/FormComponent';
// import Localhostpackages from './Components/Localhostpackages';

// function App() {
//   const [data, setdata] = useState([]);
//   const [search, setSearch] = useState();
//   const [output, setOutput] = useState([]);
//   const [onDocumentName, setOnDocumentName] = useState();
//   const [onDocumentNamespace, setOnDocumentNamespace] = useState();
//   const [onCreator, setOnCreator] = useState();
//   const [onCreatedOn, setOnCreatedOn] = useState();
//   const [onCreatorComment, setOnCreatorComment] = useState();
//   const [onGithubUrl, setonGithubUrl] = useState()
//   const [onSubmitPackages, setOnSubmitPackages] = useState()



//   const [apiData, setApiData] = useState(null);
//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const response = await fetch(' http://127.0.0.1:5000/package');
//         if (response.ok) {
//           const data = await response.json();
//           setApiData(data);
//           console.log(apiData)



          
//         } else {
//           console.error('Failed to fetch data');
//         }
//       } catch (error) {
//         console.error('Error:', error);
//       }
//     };

//     fetchData();
//   }, []);


//   function handleSearch(e) {
//       setSearch(e.target.value);
//       // console.log(e.target.value)
//       if (e.target.value === "") {
//         console.log("none");
//       }
//       else {
//         // const filterData =   data.filter((value, index) => 
//         //   console.log(value.name)
//         //   // value.name.includes(search)
//         // )
//         // console.log("its not empty")
//         // setdata(filterData)
//       }
//     }


    

//     // const fetchData = async (URL) =>{
//     //   try{
//     //     // console.log(URL)
//     //     const response = await fetch(`https://libraries.io/api/NPM/${URL}?api_key=519f64c3cb4c61b8a66640d716478d3e`);
//     //     const result = await response.json();
//     //     // const newData = [...data, result];
//     //     // setdata(newData)
//     //     setdata((prevData) => [...prevData, result]);
//     //    // setdata(result)
//     //     // console.log(result)
//     //   }
//     //   catch{
//     //  //   console.error('error in fetching data');
//     //   }
//     // };
//     // let URLs = ['base62','typescript','eslint'];

//     const packageData = [
//       { name: 'eslint', platform: 'npm', version: '8.55.0' },
//       { name: 'typescript', platform: 'npm', version: '5.3.2' },
//       { name: 'numpy', platform: 'pypi', version: '1.26.2' },
//       // ... more packages
//     ];

//     // console.log(onSubmitPackages)
      
    



//     // const fetchDataPackage = async() =>{
//     //   try{
//     //     const response = await fetch('http://localhost:8080/packages')
//     //     const result = await response.json()
//     //     console.log(result);
//     //   }
//     //   catch{
//     //     console.error('error in packages')
//     //   }
//     // }
//     // fetchDataPackage()

//     useEffect(() => {
//           apiData.forEach(async (packageInfo) => {
//           const { name, platform, version } = packageInfo;
//           await fetchData(name, platform, version);
//         }); 
//     }, []);


    

//     const fetchData = async (packageName, platform, version) => {
//       try {
//         const response = await fetch(
//           `https://libraries.io/api/${platform}/${packageName}?api_key=519f64c3cb4c61b8a66640d716478d3e`
//         );
//         const result = await response.json();
//         setdata((prevData) => [...prevData, result]);
//       } catch (error) {
//         console.error('Error fetching data:', error);
//       }
//     };

//   //   useEffect(() => {
//   //   URLs.forEach(async (url) =>{
//   //    await fetchData(url); 
//   //   })
//   // }, []);

//    const handleDocumentName = (documentName) =>{
//       setOnDocumentName(documentName)
//    }
//   const handleDocumentNamespace = (documentNamespace) =>{
//     setOnDocumentNamespace(documentNamespace)
//   }
//   const handleCreator = (creator) =>{
//     setOnCreator(creator)
//   }
//   const handleCreatedOn = (createdOn) =>{
//     setOnCreatedOn(createdOn)
//   }
//   const handleCreatorComment = (creatorComment) =>{
//     setOnCreatorComment(creatorComment)
//   }
//   const handleGithubUrl = (githubUrl) =>{
//     setonGithubUrl(githubUrl)
//   }
//   const handlePackage = (apiData) =>{
//     setOnSubmitPackages(apiData)
//     console.log(onSubmitPackages)
//   }
  

//   return (
//     <>
//       <Navbar searching = {search} handleChangeSearch = {handleSearch}></Navbar>
//       <Sbomgenerator submitDocumentName={handleDocumentName} submitDocumentNamespace={handleDocumentNamespace} submitCreator={handleCreator} submitCreatedOn={handleCreatedOn} submitCreatorComment={handleCreatorComment} submitGithubUrl={handleGithubUrl} ></Sbomgenerator>
//       {/* <Sbomgenerator></Sbomgenerator> */}
//       <Documentheader outputDocumentName = {onDocumentName} outputDocumentNamespace={onDocumentNamespace} outputCreator={onCreator} outputCreatedOn={onCreatedOn} outputCreatorComment={onCreatorComment} outputGithubUrl={onGithubUrl}></Documentheader>
//       {/* <List entries = {data}></List> */}
//       <div className='list'>
//         {data.map((entry, index) => (
//           <List key={index} entries={entry} />
//         ))}
//       </div>
//       {/* <div className='list'>{data.map((value, index)=>(
//             <List entries = {data}></List> 
//       ))}</div> */}
//       <FormComponent />
//       <Localhostpackages submitPackage = {handlePackage}></Localhostpackages>
//       <div className="App">
//       <h1>React App with Local API</h1>
//       <h2>API Data</h2>
//       {apiData ? (
//         <pre>{JSON.stringify(apiData, null, 2)}</pre>
//       ) : (
//         <p>Loading...</p>
//       )}
//     </div>
//     </>
//   );
// }

// export default App;



// import React, { useState, useEffect } from 'react';
// import Navbar from './Components/Navbar';
// import List from './Components/List';
// import Sbomgenerator from './Components/Sbomgenerator1';
// import Documentheader from './Components/Documentheader';
// import FormComponent from './Components/FormComponent';
// import Localhostpackages from './Components/Localhostpackages';

// function App() {
//   const [data, setdata] = useState([]);
//   const [search, setSearch] = useState();
//   const [onDocumentName, setOnDocumentName] = useState();
//   const [onDocumentNamespace, setOnDocumentNamespace] = useState();
//   const [onCreator, setOnCreator] = useState();
//   const [onCreatedOn, setOnCreatedOn] = useState();
//   const [onCreatorComment, setOnCreatorComment] = useState();
//   const [onGithubUrl, setonGithubUrl] = useState();
//   const [onSubmitPackages, setOnSubmitPackages] = useState();
//   const [apiData, setApiData] = useState(null);

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const response = await fetch('http://localhost:5000/package');
//         if (response.ok) {
//           const data = await response.json();
//           setApiData(data);
//         } else {
//           console.error('Failed to fetch data');
//         }
//       } catch (error) {
//         console.error('Error:', error);
//       }
//     };

//     fetchData();
//   }, []);

//   useEffect(() => {
//     const fetchPackageData = async () => {
//       if (apiData) {
//         for (const packageInfo of apiData) {
//           const { name, platform, version } = packageInfo;
//           await fetchData(name, platform, version);
//         }
//       }
//     };

//     fetchPackageData();
//   }, [apiData]);

//   const fetchData = async (packageName, platform, version) => {
//     try {
//       const response = await fetch(`https://libraries.io/api/${platform}/${packageName}?api_key=519f64c3cb4c61b8a66640d716478d3e`);
//       if (response.ok) {
//         const result = await response.json();
//         setdata((prevData) => [...prevData, result]);
//       } else {
//         console.error('Failed to fetch package data:', response.statusText);
//       }
//     } catch (error) {
//       console.error('Error fetching data:', error);
//     }
//   };

//   const handleSearch = (e) => {
//     setSearch(e.target.value);
//     if (e.target.value === '') {
//       console.log('none');
//     } else {
//       // Handle filtering logic if needed
//     }
//   };

//   const handleDocumentName = (documentName) => {
//     setOnDocumentName(documentName);
//   };

//   // ... (other handle functions)

//   const handlePackage = (apiData) => {
//     setOnSubmitPackages(apiData);
//     console.log(onSubmitPackages);
//   };

//   return (
//     <>
//       <Navbar searching={search} handleChangeSearch={handleSearch}></Navbar>
//       <Sbomgenerator
//         submitDocumentName={handleDocumentName}
//         // ... (other submit functions)
//       ></Sbomgenerator>
//       <Documentheader
//         outputDocumentName={onDocumentName}
//         // ... (other output states)
//       ></Documentheader>
//       <div className='list'>
//         {data.map((entry, index) => (
//           <List key={index} entries={entry} />
//         ))}
//       </div>
//       <FormComponent />
//       <Localhostpackages submitPackage={handlePackage}></Localhostpackages>
//       <div className='App'>
//         <h1>React App with Local API</h1>
//         <h2>API Data</h2>
//         {apiData ? (
//           <pre>{JSON.stringify(apiData, null, 2)}</pre>
//         ) : (
//           <p>Loading...</p>
//         )}
//       </div>
//     </>
//   );
// }

// export default App;




