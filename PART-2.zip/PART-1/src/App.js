import logo from './logo.svg';
import './App.css';
import React, { useState, useEffect } from 'react';
import Navbar from './Components/Navbar';
import List from './Components/List';
import Sbomgenerator from './Components/Sbomgenerator1';
import Documentheader from './Components/Documentheader';
import FormComponent from './Components/FormComponent';
import Localhostpackages from './Components/Localhostpackages';
import DownloadButton from './DownloadButton';


function App() {
  const [data, setdata] = useState([]);
  const [search, setSearch] = useState();
  const [onDocumentName, setOnDocumentName] = useState();
  const [onDocumentNamespace, setOnDocumentNamespace] = useState();
  const [onCreator, setOnCreator] = useState();
  const [onCreatedOn, setOnCreatedOn] = useState();
  const [onCreatorComment, setOnCreatorComment] = useState();
  const [onGithubUrl, setonGithubUrl] = useState();
  const [onSubmitPackages, setOnSubmitPackages] = useState();

  const [apiData, setApiData] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:8080/depend');
        if (response.ok) {
          const data = await response.json();
          setApiData(data.result); // Assuming 'result' is the key containing the list of packages
          // Note: Check the actual structure of the response and adjust accordingly
        } else {
          console.error('Failed to fetch data');
        }
      } catch (error) {
        console.error('Error:', error);
      }
    };

    fetchData();
  }, []);

  function handleSearch(e) {
    setSearch(e.target.value);
    if (e.target.value === '') {
      console.log('none');
    } else {
      // Handle filtering logic if needed
    }
  }


  
  const packageData = [
    {
      direct_dependencies: [
        {
          "name": "@testing-library/jest-dom",
          "version": "^5.17.0",
          "platform": "npm"
        },
        {
          "name": "@testing-library/react",
          "version": "^13.4.0",
          "platform": "npm"
        },
        {
          "name": "@testing-library/user-event",
          "version": "^13.5.0",
          "platform": "npm"
        },
        {
          "name": "react",
          "version": "^18.2.0",
          "platform": "npm"
        },
        {
          "name": "react-dom",
          "version": "^18.2.0",
          "platform": "npm"
        },
        {
          "name": "react-router-dom",
          "version": "^6.20.0",
          "platform": "npm"
        },
        {
          "name": "react-scripts",
          "version": "5.0.1",
          "platform": "npm"
        },
        {
          "name": "web-vitals",
          "version": "^2.1.4",
          "platform": "npm"
        }
      ],
    },
  ];

  useEffect(() => {
    const fetchPackageData = async () => {
      if (packageData) {
        for (const dependencyInfo of packageData[0].direct_dependencies) {
          const { name, version, platform } = dependencyInfo;
          await fetchData(name, platform, version);
        }
      }
    };

    fetchPackageData();
  }, [packageData]);

  useEffect(() => {
    const fetchPackageData = async () => {
      if (apiData) {
        for (const dependencyInfo of apiData[0].direct_dependencies) {
          const { name, version, platform } = dependencyInfo;
          await fetchData(name, platform, version);
        }
      }
    };

    fetchPackageData();
  }, [apiData]);

  const fetchData = async (packageName, platform, version) => {
    try {
      const response = await fetch(
        `https://libraries.io/api/${platform}/${packageName}?api_key=519f64c3cb4c61b8a66640d716478d3e`
      );
      const result = await response.json();
      setdata((prevData) => [...prevData, result]);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const [filePaths, setFilePaths] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:8080/package'); // Replace with your API endpoint
        if (response.ok) {
          const data = await response.json();
          console.log(data[0]);
          setFilePaths(data[0]); // Assuming the JSON structure is an array with a single array
        } else {
          console.error('Failed to fetch data');
        }
      } catch (error) {
        console.error('Error:', error);
      }
    };

    fetchData();
  }, []);

  const handleDocumentName = (documentName) => {
    setOnDocumentName(documentName);
  };

  const handleDocumentNamespace = (documentNamespace) => {
    setOnDocumentNamespace(documentNamespace);
  };

  const handleCreator = (creator) => {
    setOnCreator(creator);
  };

  const handleCreatedOn = (createdOn) => {
    setOnCreatedOn(createdOn);
  };

  const handleCreatorComment = (creatorComment) => {
    setOnCreatorComment(creatorComment);
  };

  const handleGithubUrl = (githubUrl) => {
    setonGithubUrl(githubUrl);
  };

  const handlePackage = (apiData) => {
    setOnSubmitPackages(apiData);
    console.log(onSubmitPackages);
  };

  return (
    <>
      <Navbar searching={search} handleChangeSearch={handleSearch}></Navbar>
      <Sbomgenerator
        submitDocumentName={handleDocumentName}
        submitDocumentNamespace={handleDocumentNamespace}
        submitCreator={handleCreator}
        submitCreatedOn={handleCreatedOn}
        submitCreatorComment={handleCreatorComment}
        submitGithubUrl={handleGithubUrl}
      ></Sbomgenerator>
      <DownloadButton />

      <Documentheader
        outputDocumentName={onDocumentName}
        outputDocumentNamespace={onDocumentNamespace}
        outputCreator={onCreator}
        outputCreatedOn={onCreatedOn}
        outputCreatorComment={onCreatorComment}
        outputGithubUrl={onGithubUrl}
      ></Documentheader>
      <div className='list'>
        {data.map((entry, index) => (
          <List key={index} entries={entry} />
        ))}
      </div>
      <FormComponent />
      <Localhostpackages submitPackage={handlePackage}></Localhostpackages>
      <div className="App">
        <h1>React App with Local API</h1>
        <h2>API Data</h2>
        {apiData ? (
          <pre>{JSON.stringify(apiData, null, 2)}</pre>
        ) : (
          <p>Loading...</p>
        )}
      </div>
      <div>
      <h2>Dependencies: </h2>
      <ul>
        {filePaths?.map((filePath, index) => (
          <li key={index}>{filePath}</li>
        ))}
      </ul>
    </div>

    </>
  );
}

export default App;