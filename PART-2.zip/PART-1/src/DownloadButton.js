import React from 'react';
import html2pdf from 'html2pdf.js';

const DownloadButton = () => {
  const handleDownload = () => {
    const content = document.body;

    const options = {
      margin: 10,
      filename: 'downloaded-document.pdf',
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
    };

    html2pdf(content, options);
  };

  return (
    <button onClick={handleDownload}>Download as PDF</button>
  );
};

export default DownloadButton;