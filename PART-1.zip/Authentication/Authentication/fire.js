const firebaseConfig = {
    // apiKey: "AIzaSyAPwM5gPbYHTbU3B4wctJGhe_H5geYlASA",
    // authDomain: "notehub-94a71.firebaseapp.com",
    // projectId: "notehub-94a71",
    // storageBucket: "notehub-94a71.appspot.com",
    // messagingSenderId: "690237325149",
    // appId: "1:690237325149:web:6967b6efbc4522105c32b4",
    // measurementId: "G-Y0GFPCVLET"
  
    apiKey: "AIzaSyB9GLRqj3aXQwwYVBAe8p9ypfXfsq9yvMQ",
    authDomain: "notehub-d01ff.firebaseapp.com",
    projectId: "notehub-d01ff",
    storageBucket: "notehub-d01ff.appspot.com",
    messagingSenderId: "40600613618",
    appId: "1:40600613618:web:8e995bf8cee2e6b0f0966b",
    measurementId: "G-L8TKMW6EX2",
  };
  firebase.initializeApp(firebaseConfig);
  