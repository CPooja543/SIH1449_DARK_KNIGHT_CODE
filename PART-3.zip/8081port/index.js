
// // const express = require('express');
// // const cors = require('cors');
// // const bodyParser = require('body-parser');
// // const app = express();
// // const port = 8081;

// // app.use(cors());
// // app.use(bodyParser.json());

// // const packageData = [];
// // let repoDetails = [
// //   { repo_name: "magic-animate", repo_owner: "magic-research" }
// // ];

// // app.get('/package', (req, res) => {
// //   res.json(packageData);
// // });

// // app.get('/repodetails', (req, res) => {
// //   res.json(repoDetails);
// // });

// // app.post('/package', (req, res) => {
// //   const newData = req.body;
// //   packageData.push(newData);
// //   res.json(newData);
// // });

// // // Update repoDetails with new data from the POST request
// // app.post('/repodetails', (req, res) => {
// //   const newData = req.body;
// //   repoDetails = newData; // Update repoDetails with new data
// //   res.json(newData);
// // });

// // app.listen(port, () => {
// //   console.log(`API server is running at http://localhost:${port}`);
// // });


// const express = require('express');
// const cors = require('cors');
// const bodyParser = require('body-parser');
// const app = express();
// const port = 8080;
// const flaskUrl = 'http://127.0.0.1:5000'; // Updated Flask URL

// app.use(cors());
// app.use(bodyParser.json());

// const packageData = [];
// let repoDetails = [
//   { repo_name: "magic-animate", repo_owner: "magic-research" }
// ];

// app.get('/package', (req, res) => {
//   res.json(packageData);
// });

// app.get('/repodetails', (req, res) => {
//   res.json(repoDetails);
// });

// app.post('/package', (req, res) => {
//   const newData = req.body;
//   packageData.push(newData);
//   res.json(newData);

//   // Send details to Flask application
//   sendDetailsToFlask(newData);
// });

// // Update repoDetails with new data from the POST request
// app.post('/repodetails', (req, res) => {
//   const newData = req.body;
//   console.log('Received repo details:', newData); 
//   repoDetails = newData; // Update repoDetails with new data
//   res.json(newData);

//   // Send details to Flask application
//   sendDetailsToFlask(newData);
// });

// app.listen(port, () => {
//   console.log(`API server is running at http://localhost:${port}`);
// });



// function sendDetailsToFlask(data) {
//   // Make a POST request to the Flask application
//   const flaskEndpoint = '/analyze'; // Replace with the appropriate Flask endpoint
//   const flaskApiUrl = `${flaskUrl}${flaskEndpoint}`;

//   // Make a POST request to Flask with the data
//   fetch(flaskApiUrl, {
//     method: 'POST',
//     headers: {
//       'Content-Type': 'application/json',
//     },
//     body: JSON.stringify([data])
//   })
//   .then(response => response.json())
//   .then(result => console.log('Details sent to Flask:', result))
//   .catch(error => console.error('Error sending details to Flask:', error));
// }


const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
const port = 8080;
const flaskUrl = 'http://127.0.0.1:5000'; // Updated Flask URL

app.use(cors());
app.use(bodyParser.json());

const packageData = [];
let repoDetails = [
 { repo_name: "magic-animate", repo_owner: "magic-research" }
];

const depdata = [];

app.get('/package', (req, res) => {
 res.json(packageData);
});

app.get('/repodetails', (req, res) => {
 res.json(repoDetails);
});

app.get('/depend', (req, res) => {
  res.json(depdata);
 });
 
app.post('/package', (req, res) => {
 const newData = req.body;
 packageData.push(newData);
 res.json(newData);

 // Send details to Flask application
 sendDetailsToFlask(newData);
});

// Update repoDetails with new data from the POST request
app.post('/repodetails', (req, res) => {
 const newData = req.body;
 console.log('Received repo details:', newData); 
 repoDetails = newData; // Update repoDetails with new data
 res.json(newData);

 // Send details to Flask application
 sendDetailsToFlask(newData);
});

app.post('/depend', (req, res) => {
  const newData = req.body;
  depdata.push(newData);
  res.json(newData);
 
  // Send details to Flask application
  sendDetailsToFlask(newData);
 });

// New route to fetch data from Flask application
app.get('/dependencies', (req, res) => {
 fetchDataFromFlask(res);
});

app.listen(port, () => {
 console.log(`API server is running at http://localhost:${port}`);
});

function sendDetailsToFlask(data) {
 // Make a POST request to the Flask application
 const flaskEndpoint = '/analyze'; // Replace with the appropriate Flask endpoint
 const flaskApiUrl = `${flaskUrl}${flaskEndpoint}`;

 // Make a POST request to Flask with the data
 fetch(flaskApiUrl, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify([data])
 })
 .then(response => response.json())
 .then(result => console.log('Details sent to Flask:', result))
 .catch(error => console.error('Error sending details to Flask:', error));
}

function fetchDataFromFlask(res) {
 // Make a GET request to the Flask application
 const flaskUrl = 'http://127.0.0.1:5000/analyze';

 // Make a GET request to Flask
 fetch(flaskUrl)
  .then(response => response.json())
  .then(data => res.json(data))
  .catch(error => res.status(500).json({ error: 'Failed to fetch data from Flask application.' }));
}
